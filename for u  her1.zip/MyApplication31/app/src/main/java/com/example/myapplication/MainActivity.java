package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Button but;
TextView tex;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
but=(Button) findViewById(R.id.work);
tex=(TextView) findViewById(R.id.text1);

        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tex.setText("Please click and hold ");
            }
        });
        but.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                tex.setText("work hours\n" +

                        "\n" +
                        "     \n" +
                        "Sunday:        10:00AM - 11:00PM \n" +
                        "Monday:       10:00AM - 11:00PM\n" +
                        "Tuesday:       10:00AM - 11:00PM\n" +
                        "Wednesday:  10:00AM - 11:00PM\n" +
                        "Thursday :     10:00AM - 11:00 PM \n" +
                        "Friday :            9:00AM - 12:00PM \n" +
                        "Saturday:        9:00AM - 12:00PM");
                return false;
            }
        });
          Button StartPhone = (Button) findViewById(R.id.phone_button);
            StartPhone.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View V) {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:0555000000"));
                    startActivity(i);
                }
            });
            Button s = (Button) findViewById(R.id.About);
            s.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TextView t = (TextView) findViewById(R.id.text);
                    t.setTextSize(0);
                }
            });

        }


public void flower (View view){
        Intent intent = new Intent( this,MainActivity2.class );
    startActivity (intent);
}


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
}